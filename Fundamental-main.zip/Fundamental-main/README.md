# **Fundamental**

**[Watch Video Tutorial](https://www.youtube.com/c/YBIFoundation?sub_confirmation=1)**

**[Ask Doubt in FREE Live QnA Session](https://www.ybifoundation.org/session/live-qna-and-doubt-support)**
